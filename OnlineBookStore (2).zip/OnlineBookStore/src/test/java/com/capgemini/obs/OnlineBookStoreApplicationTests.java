package com.capgemini.obs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
