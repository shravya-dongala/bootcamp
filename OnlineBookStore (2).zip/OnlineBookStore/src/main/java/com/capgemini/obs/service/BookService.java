package com.capgemini.obs.service;

import com.capgemini.obs.Exception.BookException;

public interface BookService {

	
	public String removeBook(long bookNo) throws BookException;

}
