package com.capgemini.obs.dao;

public interface BookDao {

	public boolean removeBook(long bookNo);
}
