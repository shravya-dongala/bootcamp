package com.capgemini.obs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.obs.Exception.BookException;
import com.capgemini.obs.service.BookService;

@RestController
public class BookController {

	@Autowired
	BookService bookService;
	
	@DeleteMapping("/removeBook/{bookNo}")
	public String removeBook(@PathVariable long bookNo) throws BookException {
		try {
			return bookService.removeBook(bookNo);
		} catch (Exception exception) {
			throw new BookException(exception.getMessage());
		}

	}

}
