package com.capgemini.obs.Exception;

public class BookException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookException(String string) {
		super(string);
	}

}
