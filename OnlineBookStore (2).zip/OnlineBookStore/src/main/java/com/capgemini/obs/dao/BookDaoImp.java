package com.capgemini.obs.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.obs.Entity.BookInfo;

@Repository
public class BookDaoImp implements BookDao {

	@PersistenceContext
	EntityManager em;
	
	
	@Override
	public boolean removeBook(long bookNo) {
		// TODO Auto-generated method stub
		BookInfo book = em.find(BookInfo.class, bookNo);
		if (book != null) {
			em.remove(book);
			return true;
		} else {
			return false;
		}
	}

}
