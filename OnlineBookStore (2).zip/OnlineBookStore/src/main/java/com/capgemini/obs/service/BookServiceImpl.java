package com.capgemini.obs.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.obs.Exception.BookException;
import com.capgemini.obs.dao.BookDao;

@Service
@Transactional
public class BookServiceImpl implements BookService {

	@Autowired 
	BookDao bookDao;
	
	@Override
	public String removeBook(long bookNo) throws BookException {
		// TODO Auto-generated method stub
		if (bookDao.removeBook(bookNo))
			return "book Removed";
		else
			throw new BookException("book not found.");
	}

}
